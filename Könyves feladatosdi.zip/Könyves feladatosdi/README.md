# KP_Konyvek
###
Komplex programozás: könyvtári adatbázis létrehozás/kezelése
###
####
Megtettem mindent a tudásom szerint
####
